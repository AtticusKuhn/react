import React from 'react';

function SpecialText(){
    return(
        <div className = "SpecialText">
            I have had to design my school Python club website twice now, 
            with serval months in between each time.The 2 websites demostrate my progress as a coder, and show my growth.
        </div>
    )
}

export default SpecialText