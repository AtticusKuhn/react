import React from 'react';

function ProjectTitle(){
    return(
        <div className = "ProjectTitle">
            My Projects
        </div>
    )
}

export default ProjectTitle