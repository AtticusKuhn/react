import React from 'react';
//import Section from './Section';
import Navbar from './Navbar';
import HomeTitle from './Hometitle';
import HomeSubtitle from './HomeSubtitle'
import SelectionBox from './SelectionBox'
const divStyle = {
  left: '4px',
  height:'29px'
};
const otherstyle = {
  left: '0px'
};



function Home(){
    return(
        <div id = "Bigholder" className = "slide" >
< SelectionBox leftstyle = {divStyle} />
            <div id = "HomeColor">
                < Navbar style1 = {otherstyle} />
                < HomeTitle />
                < HomeSubtitle />
            </div>  
           
        </div>
    )
}

export default Home