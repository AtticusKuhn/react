import React from 'react';

 
class Section extends React.Component {
  render() {
    return (
        
        <div selected = {this.props.selected} id = {this.props.id} style = {this.props.style1} className = "Section">{this.props.word}</div>
     
        
        )
  }
}
export default Section