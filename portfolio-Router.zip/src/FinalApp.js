import React from 'react';
//import Section from './Section';
import Navbar from './Navbar';
import HomeTitle from './Hometitle';
import HomeSubtitle from './HomeSubtitle'
import About from './About'
import MyProjects from './MyProjects'
import Home from './Home'
import SpecialHighlight from './SpecialHighlight'
import {BrowserRouter as Router, Switch, Route} from 'react-router-dom'
function FinalApp(){
    return(
        <div  className = "slide" >
        <Router>
        <Switch>
            
                <Route path = "/" exact component = {Home}/>
                <Route path = "/About"  component = {About}/>
                <Route path = "/MyProjects"  component = {MyProjects}/>
                <Route path = "/SpecialHighlight"  component = {SpecialHighlight}/>
         
            </Switch>
            </Router>
        </div>
    )
}

export default FinalApp