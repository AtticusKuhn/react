import React from 'react';


class ViewProject extends React.Component {
  render() {
    return(
         <a  href = {this.props.href} className = "ViewProject">view project<i class="fas fa-pager"></i></a>
    )
  }
}
export default ViewProject