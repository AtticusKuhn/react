import React from 'react';
//import Section from './Section';
import Navbar from './Navbar';
import AboutTitle from './AboutTitle';
import AboutContent from './AboutContent';
import SelectionBox from './SelectionBox'

const divStyle = {
  left: '60px',
  height:"30px"
};

function About(){
    return(
        <div id = "Bigholder" className = "slide" >
             <div id = "AboutColor">

< SelectionBox leftstyle = {divStyle} />
            < Navbar />
            < AboutTitle />
             < AboutContent />
             </div>
        </div>
    )
}

export default About