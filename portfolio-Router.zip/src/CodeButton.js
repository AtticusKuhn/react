import React from 'react';



class CodeButton extends React.Component {
  render() {
    return(
         <a  href = {this.props.href} className = "CodeButton">view code<i class="fas fa-code"></i></a>
    )
  }
}
export default CodeButton