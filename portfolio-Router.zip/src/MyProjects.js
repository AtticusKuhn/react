import React from 'react';
//import Section from './Section';
import Navbar from './Navbar';
import ProjectTitle from './ProjectTitle';
import ProjectHolder from './ProjectHolder';
import SimpleGame from './images/SimpleGame.png'
import Ultimate from "./images/Ultimate.png"
import Sprouts from "./images/Sprouts.png"
import Typing from "./images/Typing.png"
import SelectionBox from './SelectionBox'

const divStyle = {
  left: '130px',
  width:"90px",
  height:"29px"
};
function MyProjects(){
    return(
        <div id = "Bigholder" className = "slide">
            <div id = "ProjectColor">
            < SelectionBox leftstyle = {divStyle} />
            < Navbar />
            < ProjectTitle />
            < ProjectHolder word = "Simple Game" desc = "My interpreation of a bullet hell" href = "https://repl.it/@AtticusKuhn/simple-game" href2 = "https://simple-game.atticuskuhn.repl.co" src = {SimpleGame} width = "2px" />
            < ProjectHolder word = "Ultimate Tic-Tac-Toe" desc = "an implementation of Ultimate TicTacToe with automatic rules enforement and color coordination"  href = "https://repl.it/@AtticusKuhn/ultimatetictactoe" href2 = 'https://ultimatetictactoe.atticuskuhn.repl.co'src= {Ultimate} />
            < ProjectHolder word = "Sprouts" desc= 'The famous mathematical game invented by John Conway' href= 'https://repl.it/@AtticusKuhn/Sprouts-1' href2 = 'https://Sprouts-1.atticuskuhn.repl.co'  src = {Sprouts} />
            < ProjectHolder word = "Typing Training" desc= 'A tool to improve your typing skills' href= 'https://repl.it/@AtticusKuhn/Typing' href2 = 'https://Typing.atticuskuhn.repl.co'  src = {Typing} />

        </div>
        </div>
    )
}

export default MyProjects