import React from 'react';
//import York from './images/York.jpg'
function HomeSubtitle(){
    return(
        <div>
            <div className = "HomeSubtitle">
                Programmer Extraordinaire
            </div>
           
        </div>
    )
}

export default HomeSubtitle