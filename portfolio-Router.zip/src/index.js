import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
//import Navbar from './Navbar';
import Home from "./Home";
import MyProjects from "./MyProjects";
import About from "./About"
import FinalApp from './FinalApp'
import SpecialHighlight from './SpecialHighlight'
import UltGif from './gifs/Ultimate Tic-Tac-Toe.gif'
import SproutsGif from './gifs/Sprouts.gif'
import TypingGif from './gifs/Typing.gif'
import SimpleGameGif from './gifs/SimpleGame.gif'
import SimpleGame from './images/SimpleGame.png'
import UltimateTicTacTow from './images/Ultimate.png'
import Sprouts from './images/Sprouts.png'
import Typing from './images/Typing.png'
ReactDOM.render(
    <div>
    <FinalApp />
    </div>,
 document.getElementById('root'));
/*
console.log("help")
ReactDOM.render(
    <div>
    <Home />
    </div>,
 document.getElementById('root'));
 let sec= document.getElementsByClassName("Section")
 function morelists(){

for( let i=0;i<sec.length;i++){
assignlist(i)
//console.log(i)
}
 }
 morelists()
 sec[0].click()
function assignlist(i){
    let sec= document.getElementsByClassName("Section");
    sec[i].addEventListener("click",()=>{
        //console.log(sec[i])
        //console.log(sec[i].className);
if(sec[i].className === "Section"){
    for(let t=0;t<sec.length;t++){
        sec[t].className = "Section"
        sec[t].style.color = "black";
    }
sec[i].className = "Section Selected";
sec[i].style.color = "#00ffcc";
//console.log(sec[i].innerText)
if(sec[i].innerText === "home"){
  ReactDOM.render(
    <div>
    <Home />
    </div>,
 document.getElementById('root'));
 morelists()  
} else if(sec[i].innerText === "about"){
  ReactDOM.render(
    <div>
    <About />
    </div>,
 document.getElementById('root'));  
 morelists()
} else if(sec[i].innerText === "my projects"){
  ReactDOM.render(
    <div>
    <MyProjects />
    </div>,
 document.getElementById('root'));  
 morelists()
 imgloop()
 console.log("eeueuruirtiteuiuiruri")
 viewprojectlisteners()
} else if(sec[i].innerText === "special highlight"){
  ReactDOM.render(
    <div>
    <SpecialHighlight />
    </div>,
 document.getElementById('root'));  
 morelists()
} 


}

    })
}
*/


//make cursor into pointer
for(let q = 0;q< document.getElementsByClassName("Section").length;q++){
 document.getElementsByClassName("Section")[q].style.cursor = "pointer";
}



//fucntion to open links in new tab
function openInNewTab(url) {
  var win = window.open(url, '_blank');
  win.focus();
}
export default openInNewTab






function viewprojectlisteners(){
    for(let y = 0;y< document.getElementsByClassName("ViewProject");y++){
        document.getElementsByClassName("ViewProject")[y].addEventListener("click",()=>{
            openInNewTab( document.getElementsByClassName("ViewProject")[y].href)
        })
    }
}



//set src to gif

 let images = document.getElementsByTagName("img")
function imgloop(){
for(let m=0;m<images.length;m++){
imglisteners(m)
console.log("e")
}
}

 imgloop()
function imglisteners(m){
 images[m].addEventListener("mouseover", ()=>{
   
     if(images[m].id === "Simple Game"){
        images[m].src =SimpleGameGif
    } else if(images[m].id === "Ultimate Tic-Tac-Toe"){
        images[m].src =UltGif
    } else if(images[m].id === "Sprouts"){
        images[m].src =SproutsGif
    } else if(images[m].id === "Typing Training"){
        images[m].src =TypingGif
    }
})
images[m].addEventListener("mouseout", ()=>{
   console.log(images[m].id)
    if(images[m].id === "Simple Game"){
        images[m].src =SimpleGame
    } else if(images[m].id === "Ultimate Tic-Tac-Toe"){
        images[m].src =UltimateTicTacTow
    } else if(images[m].id === "Sprouts"){
        images[m].src =Sprouts
    } else if(images[m].id === "Typing Training"){
        images[m].src =Typing
    }
})
}



















/*
//assign event listeners
function assignList(){
for(let i=0;i<document.getElementsByClassName("Section").length;i++){
    let sec = document.getElementsByClassName("Section")[i];
    console.log(sec.style.color);
    if(!(sec.className.includes("black") )){
sec.className += "black";
    };
     console.log(sec.className);
    document.getElementsByClassName("Section")[i].addEventListener("click",()=>{

    let sec = document.getElementsByClassName("Section")[i];
    console.log(sec.className);
    if(sec.className.includes("black")){
        sec.style.color = "#00ffcc";
    document.getElementById("Bigholder").className = ""
    setTimeout(()=>{document.getElementById("Bigholder").className = "slide"; sec.style.color = "#00ffcc";},100)
if(sec.innerText === "about"){


 ReactDOM.render(
    <div>
    <About />
    </div>,
 document.getElementById('root'));
  //assignList()
} else if(sec.innerText === "my projects"){

ReactDOM.render(
    <div>
    <MyProjects />
    </div>,
 document.getElementById('root'));
  //assignList();

}else if(sec.innerText === "home"){

ReactDOM.render(
    <div>
    <Home />
    </div>,
 document.getElementById('root'));
 //assignList()
 
}



   // console.log(document.getElementsByClassName("Section")[i].className)
     } })
    console.log(i)
    
}
}
assignList()*/