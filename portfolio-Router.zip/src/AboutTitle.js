import React from 'react';

function HomeTitle(){
    return(
        <div>
            About
        </div>
    )
}

export default HomeTitle