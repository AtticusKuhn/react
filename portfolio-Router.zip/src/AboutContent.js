import React from 'react';

function AboutContent(){
    return(
        <div id = "About Content">
            I am a programmer who likes node.js, but this is my first project in React. I
            am excited to learn this cool framework. I also love hacking (sort of), you can ask Mr.Economical about that.
            Most of my experience comes from a friend who inspired me, and also by me wanting to design a website for the school programming club.
        </div>
    )
}

export default AboutContent