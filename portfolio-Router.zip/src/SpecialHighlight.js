import React from 'react';
//import Section from './Section';
import Navbar from './Navbar';
import ProjectHolder from './ProjectHolder';
import SpecialText from './SpecialText'
import Old from './images/Old.png'
import New from './images/New.png'
import SelectionBox from './SelectionBox'

const divStyle = {
  left: '230px',
  height:'29px',
  width:'125px'
};

function SpecialHighlight(){
    return(
        <div id = "Bigholder" className = "slide">
            <div id = "SpecialColor">
            < SelectionBox leftstyle = {divStyle} />
            < Navbar />
            < SpecialText />
            < ProjectHolder word = "First Website" desc = "My very first website"   href = "https://repl.it/@PythonPC/paly"  href2 = "https://paly.pythonpc.repl.co/" src = {Old}/>
            < ProjectHolder word = "Second website" desc = "A redesign of the first website serveral months later." href = "https://repl.it/@AtticusKuhn/PalyPython2" href2 = "https://PalyPython2.atticuskuhn.repl.co" src = {New} />
            </div>
        </div>
    )
}

export default SpecialHighlight