import React from 'react';
import Section from './Section';
import {Link} from 'react-router-dom'


function Navbar(){
    return(
        <div>
      <Link to ="/">
            <Section  selected = "true" id = "HomeSection" word = "home" />
        </Link>
        <Link to= "/About">
            <Section  word = "about" />
        </Link>
        <Link to= "/MyProjects">
            <Section  word = "my projects" />
        </Link>
        <Link to= "/SpecialHighlight">
             <Section  word = "special highlight" />
        </Link>
            
        
      
        </div>
    )
}

export default Navbar