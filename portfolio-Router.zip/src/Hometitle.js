import React from 'react';

function HomeTitle(){
    return(
        <div className = "Hometitle">
            euler
        </div>
    )
}

export default HomeTitle