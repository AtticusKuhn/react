import React from 'react';

//import ReactDOM from 'react-dom';
import CodeButton from './CodeButton'
import ViewProject from './ViewProject'
class ProjectHolder extends React.Component {
  render() {
    return(
         <div className = "Holder">
            {this.props.word} <br />
            {this.props.desc}
            <br />
            < CodeButton href = {this.props.href} />
            < ViewProject href = {this.props.href2} />
            <img alt = "stuff goes here" id = {this.props.word} src = {this.props.src}></img>
         </div>
    )
  }
}
export default ProjectHolder