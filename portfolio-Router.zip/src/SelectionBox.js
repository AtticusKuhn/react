import React from 'react';

class SelectionBox extends React.Component {
  render() {
    return(
         <div  style = {this.props.leftstyle} id = "SelectionBox">
         </div>
    )
  }
}
export default SelectionBox